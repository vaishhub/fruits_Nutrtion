<html>
<head>
<title> Home Page </title>
<link rel="stylesheet" href="style.css">
</head>
<body class="body">
<div class="bg-img">
<h1 class="h1"> NutriFruit</h1>
</div>
<div class="container">
 <div class="topnav">
 <a href="">HOME</a>
 <a href="about.php">ABOUT US </a>
 <div class="dropdown">
<button class="dropbtn">FRUITS</button>
<div class="dropdown-content">
<a href="blueberry.php">Blueberry</a>
<a href="Pomegranet.php"> Pomegranat</a>
<a href="kiwi.php">Kiwi</a>
<a href="Apple.php"> Apple</a>
<a href="orange.php"> Orange</a>

</div>
</div>
 <a href="contact.php">CONTACT US</a>
 <a href="feedback.php"> FEEDBACK</a>
 <a href="login.php"> LOGIN</a>

<a href="signup.php"> SIGN UP</a>
 </div>
 </div>
</body>
</html>